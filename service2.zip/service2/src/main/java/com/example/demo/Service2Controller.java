package com.example.demo;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Service2Controller {

	 private static final Logger log = LoggerFactory.getLogger(Service2Controller.class);
	
	@Autowired
	Aggreagator aggreagator;

	@GetMapping("/getInfo")
	public User get(@RequestParam boolean check) throws URISyntaxException, InterruptedException, ExecutionException {
		
		log.info("Request received");
		if(check)
		return aggreagator.getService();
		else
		return aggreagator.getServiceAsync();
	}
	
	@GetMapping("/getStatus")
	public User getStatus(@RequestParam boolean check) throws URISyntaxException, InterruptedException, ExecutionException, IOException {
		
		log.info("Request received");

		return aggreagator.getStatus();
	}

	@GetMapping("/fetchStatus")
	public Object fetchStatus() throws URISyntaxException, InterruptedException, ExecutionException, IOException {
		
		//log.info("Request received");

		return aggreagator.fetchStatus();
	}
	
}
