package com.example.demo;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.concurrent.CompletionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class Service<T> {
	
	private static final Logger log = LoggerFactory.getLogger(Service.class);

	@Autowired
	RestTemplate restTemplate;

	public User getServiceName(){
		
		log.info("service 1 start");

		URI uri = null;
		try {
			uri = new URI("http://localhost:8080/getName");
		} catch (URISyntaxException e) {
			throw new CompletionException(e);
		}

		ResponseEntity<T> user = doCall(HttpMethod.GET, uri, User.class);
		return (User) user.getBody();

	}

	public User getServiceAge() {
		
		log.info("service 2 start");

		URI uri = null;
		try {
			uri = new URI("http://localhost:8080/getAge");
		} catch (URISyntaxException e) {
			throw new CompletionException(e);
		}

		ResponseEntity<T> user = doCall(HttpMethod.GET, uri, User.class);
		return (User) user.getBody();
	}

	private <T> ResponseEntity<T> doCall(HttpMethod method, URI url, Class res) {
		
		log.info("main service method ");
		RequestEntity<T> requestEntity = new RequestEntity<T>(method, url);
		return restTemplate.exchange(requestEntity, res);

	}

}
