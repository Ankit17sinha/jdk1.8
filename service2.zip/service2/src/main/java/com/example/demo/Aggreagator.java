package com.example.demo;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Aggreagator {

	private static final Logger log = LoggerFactory.getLogger(Aggreagator.class);

	@Autowired
	Service<?> service;

	public User getService() throws URISyntaxException, InterruptedException {
		log.info("request start");
		long start = System.currentTimeMillis();
		User u1 = service.getServiceName();
		User u2 = service.getServiceAge();

		User u3 = create(u1, u2);
		waiting();
		
		long end = System.currentTimeMillis();
		// finding the time difference and converting it into seconds
		float sec = (end - start) / 1000F;
		System.out.println(sec + " seconds");

		return u3;
	}

	public User getServiceAsync() throws URISyntaxException, InterruptedException, ExecutionException {
		log.info("request start async");

		long start = System.currentTimeMillis();

		CompletableFuture<User> u1 = CompletableFuture.supplyAsync(service::getServiceName);

		CompletableFuture<User> u2 = CompletableFuture.supplyAsync(service::getServiceAge);
		
		CompletableFuture<User> u3 = u1.thenCombine(u2, this::create);
		
		//CompletableFuture.runAsync(this::waiting);
		

		long end = System.currentTimeMillis();
		// finding the time difference and converting it into seconds
		float sec = (end - start) / 1000F;
		log.info(sec + " seconds");

		return u3.get();
	}

	public User create(User u1, User u2){
		log.info("creating user");

		
		User u3 = new User();
		u3.setName(u1.getName());
		u3.setAge(u2.getAge());
		/*
		 * try { Thread.sleep(4000); } catch (InterruptedException e) { throw new
		 * CompletionException(e); }
		 */
		log.info("created user");
		
		return u3;
	}

	public void waiting() {
		log.info("wating");

		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			throw new CompletionException(e);
		}		log.info("wating done");
	}

	public User getStatus() throws IOException {
		try {
			LoginCheck.loginCheck();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public List<Result> fetchStatus() throws IOException {
		return LoginCheck.fetchStatus();
	}
}
