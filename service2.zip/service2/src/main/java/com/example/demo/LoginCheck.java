package com.example.demo;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.springframework.util.Assert;


public class LoginCheck {
	public static void loginCheck() throws InterruptedException { 
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sinha\\Downloads\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.setHeadless(true);
		options.addArguments("--window-size=1200x600");
		Map<String, Object> prefs = new HashMap<>();

		options.setExperimentalOption("prefs", prefs);
		ChromeDriver driver = new ChromeDriver(options);
		
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
		driver.get("https://uat1.online.citi.com/US/login.do?JFP_TOKEN=8EJLNMVG");
		Thread.sleep(1000);

		WebElement username =driver.findElementByName("username");
		WebElement password =driver.findElementByName("password");

		username.sendKeys("uat1_2581");
		password.sendKeys("test123");
		

		WebElement login = driver.findElement(By.id("signInBtn"));
		login.click();

		 Assert.isTrue(verifyTextPresent(driver,"Welcome"),"Loaded");

		
		String expectedUrl = driver.getCurrentUrl();
		System.out.println(expectedUrl);
	}
	public static boolean verifyTextPresent(ChromeDriver driver, String value)
	{
		
		System.out.println("##"+driver.getPageSource().contains(value));
	  return driver.getPageSource().contains(value);
	}
	
}