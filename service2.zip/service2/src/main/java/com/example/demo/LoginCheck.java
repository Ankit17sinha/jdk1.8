package com.example.demo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class LoginCheck {

	public static void loginCheck() throws InterruptedException, IOException {

		ChromeDriver driver = configureDriver(true);

		List<String> inputList = new ArrayList<>();
		BufferedReader csvReader = new BufferedReader(new FileReader(
				"C:\\Users\\sinha\\Documents\\angularSpringProject\\spring\\service2\\src\\main\\resources\\static\\input.csv"));
		String row = null;
		while ((row = csvReader.readLine()) != null) {
			inputList.add(row);
		}
		boolean runEver = true;
		while (runEver) {
			for (String input : inputList) {
				String[] data = input.split(",");
				String url = data[0];
				String user = data[1];
				String password = data[2];
				String verifyByText = data[3];
				boolean loggedIn = false;
				try {
					performLogin(driver, url, user, password);
					loggedIn = checkLogin(driver, verifyByText);
					performLogout(driver);
				} catch (Exception e) {
					loggedIn = false;
					System.out.println("Exception in login");
				}
				writeStatusInExcel(url, user, password, verifyByText, loggedIn);

			}
		}

		csvReader.close();
	}

	private static void performLogout(ChromeDriver driver) {
		driver.manage().deleteAllCookies();
	}

	private static void writeStatusInExcel(String url, String user, String password, String verifyByText,
			boolean loggedIn) throws IOException {
		FileInputStream file = new FileInputStream(new File(
				"C:\\Users\\sinha\\Documents\\angularSpringProject\\spring\\service2\\src\\main\\resources\\static\\output.xlsx"));

		XSSFWorkbook workbook = new XSSFWorkbook(file);

		XSSFSheet sheet = workbook.getSheetAt(0);

		Iterator<Row> rowIterator = sheet.iterator();
		boolean rowExists = false;
		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();

			Iterator<Cell> cellIterator = row.cellIterator();

			rowExists = cellIterator.next().getStringCellValue().equalsIgnoreCase(url)
					&& cellIterator.next().getStringCellValue().equalsIgnoreCase(user)
					&& cellIterator.next().getStringCellValue().equalsIgnoreCase(password)
					&& cellIterator.next().getStringCellValue().equalsIgnoreCase(verifyByText);
			String existingData = "";
			if (rowExists) {
				try {
					existingData = cellIterator.next().getStringCellValue();

				} catch (Exception e) {

				}

				String data = new Date().toString() + "," + String.valueOf(loggedIn);
				row.getCell(4).setCellValue(existingData + "|" + data);
				break;
			}

		}
		if (!rowExists) {
			String data = new Date().toString() + "," + loggedIn;
			int rows = sheet.getLastRowNum();
			sheet.shiftRows(0, rows, 1);
			sheet.createRow(0);
			sheet.getRow(0).createCell(0).setCellValue(url);
			sheet.getRow(0).createCell(1).setCellValue(user);
			sheet.getRow(0).createCell(2).setCellValue(password);
			sheet.getRow(0).createCell(3).setCellValue(verifyByText);
			sheet.getRow(0).createCell(4).setCellValue(data);

		}

		// workbook.close();
		FileOutputStream out = new FileOutputStream(new File(
				"C:\\Users\\sinha\\Documents\\angularSpringProject\\spring\\service2\\src\\main\\resources\\static\\output.xlsx"));
		workbook.write(out);
		out.close();
		workbook.close();
	}

	private static boolean checkLogin(ChromeDriver driver, String verifyByText) {
		return verifyTextPresent(driver, verifyByText);
	}

	private static void performLogin(ChromeDriver driver, String url, String user, String pswd) {
		driver.get(url);

		WebElement username = driver.findElementByName("username");
		WebElement password = driver.findElementByName("password");

		username.sendKeys(user);
		password.sendKeys(pswd);

		WebElement login = driver.findElement(By.id("signInBtn"));
		login.click();

	}

	public static boolean verifyTextPresent(ChromeDriver driver, String value) {

		if (!driver.getPageSource().contains(value)) {
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("##" + value + driver.getPageSource().contains(value));

		return driver.getPageSource().contains(value);
	}

	public static ChromeDriver configureDriver(boolean headless) {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\sinha\\Downloads\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.setHeadless(headless);
		options.addArguments("--window-size=1200x600");
		options.addArguments("--no-sandbox");
		options.addArguments("--disable-dev-shm-usage");

		options.setBinary("C:\\Users\\sinha\\Downloads\\GoogleChromePortable\\App\\Chrome-bin\\chrome.exe");
		Map<String, Object> prefs = new HashMap<>();
		options.setExperimentalOption("prefs", prefs);
		ChromeDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
		return driver;
	}

	public static List<Result> fetchStatus() throws IOException {

		FileInputStream file = new FileInputStream(new File(
				"C:\\Users\\sinha\\Documents\\angularSpringProject\\spring\\service2\\src\\main\\resources\\static\\output.xlsx"));

		XSSFWorkbook workbook = new XSSFWorkbook(file);

		XSSFSheet sheet = workbook.getSheetAt(0);
		List<Result> resultList = new ArrayList<>();
		Iterator<Row> rowIterator = sheet.iterator();
		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();

			Iterator<Cell> cellIterator = row.cellIterator();

			String url = cellIterator.next().getStringCellValue();
			String user = cellIterator.next().getStringCellValue();
			String password = cellIterator.next().getStringCellValue();
			String verifyByText = cellIterator.next().getStringCellValue();
			String status = cellIterator.next().getStringCellValue();
			
			Result result = new Result();
			result.setUser(user);
			result.setUrl(url);
			result.setPassword(password);
			result.setVerifyByText(verifyByText);
			result.setStatus(status);
			resultList.add(result);
		}
		workbook.close();
		
		return resultList;
	}
}